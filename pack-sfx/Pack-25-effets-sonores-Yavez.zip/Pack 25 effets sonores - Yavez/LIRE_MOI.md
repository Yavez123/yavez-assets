# Pack SFX TikTok

25 sons WAV sans doublons, nommés et classés par source.

- `01_Viralup` : 10 sons de @viralup.eu.
- `02_Miracamp` : 6 sons de @miracampschool.
- `03_DorianGrowth` : 9 sons de @doriangrowth.
- `ECOUTER.html` : catalogue local pour écouter les fichiers et les retrouver par nom.
- `INDEX.csv` : liste des fichiers, durées et positions de début/fin dans les sources.

Les doublons ont été regroupés : FAHHH/FAHHHH, CORE, BRUH, HUH, BOOM/DRAMATIC VINE/VINE BOOM et IMPOSTER/AMONG US. Les autres noms figurent dans le catalogue et l'index. IMPOSTER a été remplacé par l'extrait AMONG US de la troisième vidéo, plus complet et sans narration.

Troisième vidéo : huit nouveaux sons ont été ajoutés (CLOCK TICK, CHAN DRAMA, DOGE BONK, RISER POPULAR, POP, ANIME WOW, CHECK MARK et MARIO JUMP). Les sons BRUH, HUH et VINE BOOM étaient déjà présents ; AMONG US correspond à IMPOSTER.

Quatrième vidéo : le VINE BOOM est déjà dans ce pack. Les deux autres effets cités, CINEMATIC WHOOSH et APPLE UI CLICK / NOTIFICATION POP, sont mêlés à la narration. Les essais de séparation n'ont pas fourni d'extraits assez propres : ils ne sont donc pas ajoutés à la bibliothèque. Leurs fichiers audio d'origine permettraient de compléter le pack sans voix.

Format : WAV PCM 24 bits, 44,1 kHz, stéréo. Importer directement les WAV dans le logiciel de montage.

Découpe mesurée sur la piste audio décodée, à l'échantillon près. Microfondus de 1 ms au début et 4 ms à la fin pour limiter les clics de coupe. Vitesse inchangée. Volume conservé, sauf une légère baisse sur 3 fichiers pour éviter d'ajouter de la saturation lors de la conversion.

Ce sont les extraits exacts de la piste publiée, pas des recréations. La compression TikTok et tout fond déjà mélangé au son restent présents. La fin de certains effets est déjà abrégée dans les vidéos : les fichiers conservent la portion disponible.

Sources :
- Vidéo 1 : https://vm.tiktok.com/ZN8ArSQn2/
- Vidéo 2 : https://vm.tiktok.com/ZN8ArDFnK/
- Vidéo 3 : https://vm.tiktok.com/ZN8AhRcB7/
- Vidéo 4 : https://vm.tiktok.com/ZN8AhRHo2/
